
import { ExtractedIntel, Message, IntelItem, CallbackLog, PredatorMetrics } from "./types";

export interface HeuristicSignals {
  scamScore: number;
  detectedVectors: string[];
  signals: string[];
  intel: ExtractedIntel;
  predatorMetrics: PredatorMetrics;
}

// --- ADVANCED CINEMATIC AUDIO KERNEL ---
class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  
  // Drone Components
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;
  private droneGain: GainNode | null = null;
  private lfo: OscillatorNode | null = null;

  // State
  public isMuted: boolean = false; 
  public masterVolume: number = 0.5;
  private threatLevel: number = 0;
  private isMonitoring: boolean = false;
  private geigerTimeout: number | null = null;
  private alarmInterval: number | null = null;

  constructor() {
    // Lazy init via user interaction
  }

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
      this.setVolume(this.masterVolume * 100);
      
      // Start the background atmosphere immediately upon first interaction
      this.startDrone();
      this.startGeigerLoop();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(val: number) {
    this.masterVolume = Math.max(0, Math.min(1, val / 100));
    if (this.masterGain && this.ctx) {
       this.masterGain.gain.setTargetAtTime(this.masterVolume, this.ctx.currentTime, 0.1);
    }
  }

  public setThreatLevel(score: number) {
    this.threatLevel = score;
    this.modulateDrone();
    this.manageAlarm();
  }

  // --- 1. PROCEDURAL DARK DRONE (ATMOSPHERE) ---
  private startDrone() {
    if (!this.ctx || !this.masterGain || this.droneOsc1) return;

    // Dual Oscillator Sawtooth Drone (The "Void" Sound)
    this.droneOsc1 = this.ctx.createOscillator();
    this.droneOsc2 = this.ctx.createOscillator();
    this.droneOsc1.type = 'sawtooth';
    this.droneOsc2.type = 'sawtooth';

    // Base frequencies (Low C ~ 65Hz)
    this.droneOsc1.frequency.value = 65.41; 
    this.droneOsc2.frequency.value = 65.41 * 1.01; // Detuned for "beating" effect

    // Filter (Muffles the sound initially)
    this.droneFilter = this.ctx.createBiquadFilter();
    this.droneFilter.type = 'lowpass';
    this.droneFilter.frequency.value = 200; // Start dark
    this.droneFilter.Q.value = 1;

    // LFO for instability
    this.lfo = this.ctx.createOscillator();
    this.lfo.type = 'sine';
    this.lfo.frequency.value = 0.1; // Slow breathing
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 100;
    this.lfo.connect(lfoGain);
    lfoGain.connect(this.droneFilter.frequency);

    // Gain
    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.value = 0.15; // Base level

    // Graph
    this.droneOsc1.connect(this.droneFilter);
    this.droneOsc2.connect(this.droneFilter);
    this.droneFilter.connect(this.droneGain);
    this.droneGain.connect(this.masterGain);

    this.droneOsc1.start();
    this.droneOsc2.start();
    this.lfo.start();
  }

  private modulateDrone() {
    if (!this.ctx || !this.droneFilter || !this.droneOsc1 || !this.droneOsc2) return;
    
    // Higher threat = Higher Filter Cutoff (Sound gets brighter/harsher)
    // Base: 200Hz, Max Threat: 1500Hz
    const targetFreq = 200 + (this.threatLevel * 1300);
    this.droneFilter.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 2);

    // Higher threat = More detuning (More dissonance)
    const detune = 1.01 + (this.threatLevel * 0.05);
    this.droneOsc2.frequency.setTargetAtTime(65.41 * detune, this.ctx.currentTime, 2);
  }

  // --- 2. DYNAMIC GEIGER COUNTER (THREAT INDICATOR) ---
  private startGeigerLoop() {
    const loop = () => {
        if (!this.ctx) return;
        
        // Only click if there is ANY threat (> 0.05)
        if (this.threatLevel > 0.05) {
            this.playGeigerClick();
        }

        // Calculate next click delay based on threat
        // Threat 0.1 -> Slow (~1500ms)
        // Threat 0.9 -> Fast (~80ms)
        // Formula: Exponential decay of time delay
        const minDelay = 80;
        const maxDelay = 2000;
        // Inverse threat mapping
        const delay = maxDelay - (Math.pow(this.threatLevel, 0.5) * (maxDelay - minDelay));
        
        // Add randomness (jitter) to make it organic
        const jitter = delay * 0.3 * (Math.random() - 0.5);
        const nextTime = Math.max(50, delay + jitter);

        this.geigerTimeout = window.setTimeout(loop, nextTime);
    };
    loop();
  }

  private playGeigerClick() {
    if (!this.ctx || !this.masterGain) return;
    
    // Create a tiny burst of filtered noise
    const bufferSize = this.ctx.sampleRate * 0.005; // 5ms
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1);
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const noiseFilter = this.ctx.createBiquadFilter();
    noiseFilter.type = 'highpass';
    noiseFilter.frequency.value = 1000;

    const clickGain = this.ctx.createGain();
    // Louder clicks at higher threat
    clickGain.gain.value = 0.05 + (this.threatLevel * 0.1); 

    noise.connect(noiseFilter);
    noiseFilter.connect(clickGain);
    clickGain.connect(this.masterGain);
    
    noise.start();
  }

  // --- 3. CRITICAL ALARM (RED ALERT) ---
  private manageAlarm() {
     if (this.threatLevel > 0.8) {
         if (!this.alarmInterval) {
             this.startAlarm();
         }
     } else {
         if (this.alarmInterval) {
             clearInterval(this.alarmInterval);
             this.alarmInterval = null;
         }
     }
  }

  private startAlarm() {
      // Periodic high-pitched sine beep
      this.alarmInterval = window.setInterval(() => {
          if (!this.ctx || !this.masterGain) return;
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          
          osc.type = 'sine';
          osc.frequency.setValueAtTime(1200, this.ctx.currentTime);
          osc.frequency.linearRampToValueAtTime(800, this.ctx.currentTime + 0.15); // Drop pitch
          
          gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);
          
          osc.connect(gain);
          gain.connect(this.masterGain);
          osc.start();
          osc.stop(this.ctx.currentTime + 0.2);
      }, 800); // Pulse every 800ms
  }

  // --- SFX: UI INTERACTIONS ---
  
  public playBlip() {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    // Tech chirp
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(2000, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1000, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.05);
  }

  public playActivation() {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    // Power-up swell
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(110, this.ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(880, this.ctx.currentTime + 0.3);

    gain.gain.setValueAtTime(0, this.ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.1, this.ctx.currentTime + 0.1);
    gain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 0.4);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.4);
  }

  public playSuccess() {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    // Positive chime
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.frequency.setValueAtTime(440, this.ctx.currentTime);
    osc.frequency.setValueAtTime(880, this.ctx.currentTime + 0.1);
    
    gain.gain.setValueAtTime(0.1, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.3);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.3);
  }
  
  public playTypewriter() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    
    // Mechanical click
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(400, this.ctx.currentTime);
    
    // Very short noise burst simulation
    gain.gain.setValueAtTime(0.02, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.03);
    
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.03);
  }
}

export const soundEngine = new SoundEngine();

export const analyzeMessageHeuristically = (messages: Message[]): HeuristicSignals => {
  const currentMessage = messages[messages.length - 1]?.text || "";
  const allText = messages.map(m => m.text).join(' ').toLowerCase();
  
  // --- Enhanced Cyber-Forensics Regex Library ---

  // 1. Identity & Financial Assets
  const urlRegex = /https?:\/\/[^\s$.?#].[^\s]*/gi;
  const upiRegex = /[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}/g;
  const phoneRegex = /(?:\+91[\-\s]?)?[6789]\d{9}/g;
  const bankAccountRegex = /\b\d{9,18}\b/g;
  const ifscRegex = /[A-Z]{4}0[A-Z0-9]{6}/g;

  // 2. Behavioral Triggers (Psychological Warfare Detection)
  const urgencyRegex = /\b(immediately|urgent|within 24 hours|suspended|blocked|expiration|expires|lapse|final notice|last chance|tonight|police|quick|hurry|fast)\b/i;
  const authorityRegex = /\b(police|reserve bank|rbi|court|legal action|manager|department|verification|cyber crime|tax department|income tax|cbi|narcotics|lawyer|judge|official|adhikari)\b/i;
  const greedRegex = /\b(lottery|winner|prize|cashback|refund|credited|congratulations|claim now|bonus|iphone|macbook|offer|exclusive|profit|double|earn daily)\b/i;
  const fearRegex = /\b(jail|arrest|warrant|disconnect|freeze|seize|penalty|fine|handcuff|fir|case|lawsuit|investigation|drugs|illegal)\b/i;
  const exploitationRegex = /\b(family|help|hospital|emergency|shame|leak|viral|video|nude|private|trust|friend|dear|beg|please)\b/i;

  // 3. Specific Scam Structures
  const payToReceiveRegex = /(pay|send|transfer).* (receive|get|refund|win|reward|claim)/i;
  const scanQrRegex = /scan.*qr|qr.*code|google.*pay.*scanner/i;
  const pinToReceiveRegex = /enter.*pin.*receive|pin.*to.*get|balance.*check/i;
  const remoteAccessRegex = /\b(anydesk|teamviewer|quicksupport|rustdesk|screen share|remote support)\b/i;
  const jobScamRegex = /\b(daily income|part time|work from home|wfh|telegram|whatsapp|hr manager|hiring|review.*task|prepaid.*task|youtube.*like)\b/i;
  const cryptoRegex = /\b(crypto|bitcoin|usdt|investment|profit|trading|binance|coinbase|doubling)\b/i;
  
  const electricityRegex = /\b(electricity|power|bill|disconnect|adhikari|officer|update.*number|light.*cut)\b/i;
  const courierRegex = /\b(fedex|dhl|bluedart|parcel|customs|illegal|drugs|narcotics|mumbai police|skype)\b/i;
  const sextortionRegex = /\b(video|leak|upload|viral|nude|private|call|record|social media|family|friends)\b/i;

  // 4. Enhanced Phishing Indicators
  const suspiciousDomainsRegex = /bit\.ly|t\.me|tinyurl\.com|ow\.ly|is\.gd|cutt\.ly|rebrand\.ly|ngrok\.io|serveo\.net|localtunnel\.me|duckdns\.org|firebaseapp\.com|000webhostapp\.com|pages\.dev|vercel\.app|netlify\.app/i;
  const maliciousFileRegex = /\.(apk|exe|bat|sh|vbs|jar)$/i;

  // 5. Sophisticated Intent Combinations (Cross-Correlation)
  const coercionContext = /(police|cbi|rbi|court|arrest|jail|warrant).*(pay|transfer|money|fine|bail|deposit)/i;
  const bankingPhishingContext = /(bank|kyc|pan|aadhaar|update).*(link|click|form|submit).*(http)/i;
  const jobFeeContext = /(job|hiring|salary|income).*(registration|fee|deposit|security|charge).*(pay|send)/i;

  const criticalKeywords = {
    'kyc': 0.8, 'block': 0.7, 'suspended': 0.8, 'verify': 0.5, 
    'otp': 0.9, 'cvv': 0.95, 'pin': 0.8, 'password': 0.7,
    'lottery': 0.9, 'reward': 0.6, 'winner': 0.7, 'cashback': 0.5,
    'urgent': 0.6, 'immediate': 0.6, 'compliance': 0.5, 'threat': 0.7,
    'frozen': 0.8, 'pan': 0.6, 'aadhaar': 0.6, 'refund': 0.7,
    'apk': 0.9, 'install': 0.4, 'video': 0.6, 'customs': 0.7,
    'apk download': 0.95, 'merchant': 0.6, 'gateway': 0.6
  };

  const signals: string[] = [];
  const detectedVectors: string[] = [];
  let heuristicScore = 0;

  // --- Analysis Logic ---
  if (payToReceiveRegex.test(allText)) { signals.push("Reverse-payment baiting"); heuristicScore += 0.4; }
  if (scanQrRegex.test(allText)) { signals.push("QR-code social engineering"); heuristicScore += 0.5; }
  if (pinToReceiveRegex.test(allText)) { signals.push("PIN-harvesting detected"); heuristicScore += 0.6; }
  if (remoteAccessRegex.test(allText)) { signals.push("Remote Access Trojan (RAT) Bait"); detectedVectors.push("TECH_SUPPORT_SCAM"); heuristicScore += 0.8; }
  if (maliciousFileRegex.test(allText)) { signals.push("Malicious File Signature (APK/EXE)"); detectedVectors.push("MALWARE_DISTRIBUTION"); heuristicScore += 0.9; }
  
  let urgencyScore = 0;
  let authorityScore = 0;
  let exploitationScore = 0;

  if (urgencyRegex.test(allText)) { signals.push("Artificial Urgency"); heuristicScore += 0.2; urgencyScore += 40; }
  if (authorityRegex.test(allText)) { signals.push("Authority Impersonation"); heuristicScore += 0.3; authorityScore += 50; }
  if (fearRegex.test(allText)) { signals.push("Coercive/Fear Tactics"); heuristicScore += 0.3; authorityScore += 30; exploitationScore += 30; }
  if (greedRegex.test(allText)) { signals.push("Incentivized Action (Greed)"); heuristicScore += 0.2; exploitationScore += 40; }
  if (exploitationRegex.test(allText)) { signals.push("Emotional Exploitation"); heuristicScore += 0.2; exploitationScore += 50; }

  if (suspiciousDomainsRegex.test(allText)) { 
    signals.push("Obfuscated/Tunneling Link"); 
    detectedVectors.push("PHISHING_ATTACK");
    heuristicScore += 0.4; 
  }

  if (coercionContext.test(allText)) {
      signals.push("Coercive Extortion Pattern");
      detectedVectors.push("COURIER_SCAM");
      heuristicScore += 0.8;
      authorityScore += 50;
      fearRegex.test(allText) ? urgencyScore += 30 : null;
  }
  if (bankingPhishingContext.test(allText)) {
      signals.push("Banking Credential Phishing");
      detectedVectors.push("BANKING_KYC_FRAUD");
      heuristicScore += 0.8;
      authorityScore += 20;
      urgencyScore += 20;
  }
  if (jobFeeContext.test(allText)) {
      signals.push("Advance Fee Job Fraud");
      detectedVectors.push("TASK_JOB_SCAM");
      heuristicScore += 0.7;
      exploitationScore += 40;
  }

  if (/kyc|pan|aadhaar|account.*(block|suspend|frozen)/i.test(allText)) { detectedVectors.push("BANKING_KYC_FRAUD"); heuristicScore += 0.4; urgencyScore += 30; authorityScore += 20; }
  if (/refund|cashback|payment.*(pending|receive)/i.test(allText)) { detectedVectors.push("UPI_REFUND_SCAM"); heuristicScore += 0.3; exploitationScore += 30; }
  if (jobScamRegex.test(allText)) { detectedVectors.push("TASK_JOB_SCAM"); heuristicScore += 0.4; exploitationScore += 40; }
  if (cryptoRegex.test(allText)) { detectedVectors.push("CRYPTO_SCAM"); heuristicScore += 0.3; exploitationScore += 40; }
  if (electricityRegex.test(allText)) { detectedVectors.push("UTILITY_SCAM"); heuristicScore += 0.5; urgencyScore += 50; authorityScore += 20; }
  if (courierRegex.test(allText) && !coercionContext.test(allText)) { detectedVectors.push("COURIER_SCAM"); heuristicScore += 0.6; authorityScore += 60; fearRegex.test(allText) ? urgencyScore += 30 : null; }
  if (sextortionRegex.test(allText)) { detectedVectors.push("SEXTORTION"); heuristicScore += 0.7; exploitationScore += 80; urgencyScore += 20; }

  const p_urgency = Math.min(urgencyScore, 100);
  const p_authority = Math.min(authorityScore, 100);
  const p_exploitation = Math.min(exploitationScore, 100);
  
  let dominant: 'URGENCY' | 'AUTHORITY' | 'EXPLOITATION' = 'EXPLOITATION';
  if (p_urgency > p_authority && p_urgency > p_exploitation) dominant = 'URGENCY';
  if (p_authority > p_urgency && p_authority > p_exploitation) dominant = 'AUTHORITY';

  const predatorMetrics: PredatorMetrics = {
    urgency_score: p_urgency,
    authority_score: p_authority,
    exploitation_score: p_exploitation,
    dominant_vector: dominant
  };

  const mapToIntel = (matches: string[] | null, provenance: string): IntelItem[] => {
    if (!matches) return [];
    return Array.from(new Set(matches)).map(val => ({
      value: val,
      source_idx: messages.length - 1,
      confidence: 0.9,
      provenance,
      evidence_snippets: [currentMessage],
      first_msg_idx: messages.length - 1,
      confirmation_count: 1,
      confidence_breakdown: {
        pattern_score: 0.9,
        context_score: 0.5,
        reinforcement_score: 0,
        decay_penalty: 0
      }
    }));
  };

  const intel: ExtractedIntel = {
    bank_accounts: mapToIntel(allText.match(bankAccountRegex), 'regex_bank'),
    upi_ids: mapToIntel(allText.match(upiRegex), 'regex_upi'),
    links: mapToIntel(allText.match(urlRegex), 'regex_url').map(item => ({ ...item, domain: 'extracted' })),
    phone_numbers: mapToIntel(allText.match(phoneRegex), 'regex_phone'),
    ifsc_codes: mapToIntel(allText.match(ifscRegex), 'regex_ifsc'),
    suspiciousKeywords: Object.keys(criticalKeywords)
      .filter(k => allText.includes(k))
      .map(k => ({ value: k, source_idx: messages.length - 1, confidence: 0.8 }))
  };

  if ((intel.bank_accounts.length > 0 || intel.upi_ids.length > 0) && (urgencyRegex.test(allText) || greedRegex.test(allText))) {
    heuristicScore += 0.3;
  }

  return { 
    scamScore: Math.min(heuristicScore, 1.0), 
    detectedVectors: Array.from(new Set(detectedVectors)), 
    signals: Array.from(new Set(signals)), 
    intel,
    predatorMetrics
  };
};

export const sendCallbackWithRetry = async (
  payload: any, 
  onLog: (log: CallbackLog) => void,
  maxRetries: number = 3
): Promise<boolean> => {
  const messageId = payload.messageId;
  const apiKey = process.env.API_KEY || "DEV_HACKATHON_KEY";
  let attempt = 1;
  
  const executeAttempt = async (): Promise<boolean> => {
    const log: CallbackLog = {
      id: `${messageId}-${attempt}`,
      timestamp: Date.now(),
      status: 'pending',
      attempt,
      payload: payload
    };
    onLog(log);

    try {
      const targetUrl = `https://hackathon.guvi.in/api/updateHoneyPotFinalResult?key=${apiKey}`;
      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey },
        body: JSON.stringify(payload)
      });
      const updatedLog: CallbackLog = {
        ...log,
        status: response.ok ? 'success' : 'failed',
        httpStatus: response.status,
        response: response.ok ? 'ACK' : 'UPSTREAM_ERROR'
      };
      onLog(updatedLog);
      return response.ok;
    } catch (error) {
      if (attempt < maxRetries) {
        attempt++;
        await new Promise(r => setTimeout(r, 2000));
        return executeAttempt();
      }
      onLog({ ...log, status: 'failed', response: 'NETWORK_ERROR' });
      return false;
    }
  };
  return executeAttempt();
};
