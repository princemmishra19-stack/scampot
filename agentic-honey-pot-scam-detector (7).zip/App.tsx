
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Message, ExtractedIntel, UnifiedAnalysis, 
  ScamEvent, AgentState, GlobalKPIs, 
  PredatorMetrics, LegalSummary, NetworkGraphPayload, GraphNode, GraphEdge, ShadowTelemetry, CallbackPayload
} from './types';
import { processIncomingMessage } from './geminiService';
import { analyzeMessageHeuristically, sendCallbackWithRetry, soundEngine } from './utils';

// Declaration for Web Speech API and jsQR
declare global {
  interface Window {
    webkitSpeechRecognition: any;
    jsQR: any;
    jspdf: any;
  }
}

// --- TYPES FOR ARCHIVING ---
interface ArchivedSession {
  id: string;
  timestamp: number;
  threatScore: number;
  messages: Message[];
  intel: ExtractedIntel;
  metrics: PredatorMetrics;
  personaUsed: string;
  status: 'NEUTRALIZED' | 'ACTIVE' | 'PENDING';
}

// --- MODAL COMPONENTS ---

const SystemArchModal: React.FC<{ onClose: () => void }> = ({ onClose }) => (
  <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-200">
    <div className="bg-void-900 border border-crimson/30 rounded-lg shadow-[0_0_30px_rgba(255,0,51,0.15)] w-full max-w-4xl max-h-[90vh] overflow-y-auto custom-scrollbar flex flex-col">
      <div className="flex items-center justify-between p-6 border-b border-crimson/20 bg-void-950 sticky top-0 z-10">
        <h2 className="text-xl font-black tracking-[0.2em] text-white uppercase flex items-center gap-3">
          <i className="fas fa-network-wired text-crimson animate-pulse"></i> System Architecture
        </h2>
        <button onClick={onClose} className="text-slate-500 hover:text-crimson transition-colors">
          <i className="fas fa-times text-xl"></i>
        </button>
      </div>
      
      <div className="p-8 space-y-8 text-slate-300 font-sans">
        <section>
          <h3 className="text-sm font-bold text-crimson uppercase tracking-widest mb-4 border-b border-crimson/20 pb-2">The Consensus Engine (Input Analysis)</h3>
          <p className="text-sm leading-relaxed mb-4 text-slate-400">
             Raashya orchestrates three specialized analytical sub-agents for every incoming message:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             <div className="bg-void-800 p-4 rounded border border-crimson/10 border-l-2 border-l-crimson hover:bg-void-700 transition-colors">
                <div className="text-crimson font-bold text-xs uppercase mb-2">Agent Hunter</div>
                <p className="text-[10px] text-slate-400">Scans for hard forensic signals (UPI patterns, APK hashes, Phishing URLs) using high-speed RegEx heuristics.</p>
             </div>
             <div className="bg-void-800 p-4 rounded border border-crimson/10 border-l-2 border-l-amber-600 hover:bg-void-700 transition-colors">
                <div className="text-amber-500 font-bold text-xs uppercase mb-2">Agent Skeptic</div>
                <p className="text-[10px] text-slate-400">Risk validation & false-positive reduction. Detects logical fallacies (e.g., "RBI Official" asking for OTP).</p>
             </div>
             <div className="bg-void-800 p-4 rounded border border-crimson/10 border-l-2 border-l-cyan-600 hover:bg-void-700 transition-colors">
                <div className="text-cyan-500 font-bold text-xs uppercase mb-2">Agent Linguist</div>
                <p className="text-[10px] text-slate-400">Language tone & manipulation analysis. Maps the Predator Intent Radar (Urgency, Deception, Greed).</p>
             </div>
          </div>
        </section>
      </div>
    </div>
  </div>
);

const SettingsModal: React.FC<{ 
  onClose: () => void, 
  settings: any, 
  setSettings: (s: any) => void 
}> = ({ onClose, settings, setSettings }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4 animate-in fade-in duration-200">
       <div className="bg-void-900 border border-crimson/30 rounded-lg shadow-[0_0_50px_rgba(255,0,51,0.2)] w-full max-w-md">
          <div className="flex items-center justify-between p-4 border-b border-crimson/20 bg-void-950 rounded-t-lg">
            <h2 className="text-sm font-bold tracking-widest text-white uppercase"><i className="fas fa-cog mr-2 text-crimson"></i> System Configuration</h2>
            <button onClick={onClose} className="text-slate-500 hover:text-white"><i className="fas fa-times"></i></button>
          </div>
          <div className="p-6 space-y-6">
             <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase">Audio Output Level</label>
                <input 
                  type="range" 
                  min="0" max="100" 
                  className="w-full accent-crimson h-1 bg-void-700 rounded appearance-none cursor-pointer"
                  value={settings.volume}
                  onChange={(e) => setSettings({...settings, volume: parseInt(e.target.value)})}
                />
             </div>
             <div className="flex items-center justify-between">
                <div className="flex flex-col">
                   <span className="text-xs font-bold text-slate-400 uppercase">Safe Mode (Mask PII)</span>
                   <span className="text-[9px] text-slate-600">Obfuscate sensitive data in logs</span>
                </div>
                <button 
                  onClick={() => setSettings({...settings, safeMode: !settings.safeMode})}
                  className={`w-10 h-5 rounded-full relative transition-colors ${settings.safeMode ? 'bg-crimson shadow-[0_0_10px_#ff0033]' : 'bg-void-700'}`}
                >
                  <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${settings.safeMode ? 'left-6' : 'left-1'}`}></div>
                </button>
             </div>
             <div className="flex items-center justify-between">
                <div className="flex flex-col">
                   <span className="text-xs font-bold text-slate-400 uppercase">Auto-Stall Mode</span>
                   <span className="text-[9px] text-slate-600">AI replies automatically to delay attacker</span>
                </div>
                <button 
                  onClick={() => setSettings({...settings, autoStall: !settings.autoStall})}
                  className={`w-10 h-5 rounded-full relative transition-colors ${settings.autoStall ? 'bg-crimson shadow-[0_0_10px_#ff0033]' : 'bg-void-700'}`}
                >
                  <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${settings.autoStall ? 'left-6' : 'left-1'}`}></div>
                </button>
             </div>
          </div>
          <div className="p-4 border-t border-crimson/20 bg-void-950/50 rounded-b-lg flex justify-end">
             <button onClick={onClose} className="px-4 py-2 bg-crimson/10 border border-crimson/50 text-crimson text-xs font-bold rounded hover:bg-crimson hover:text-black transition-all">SAVE CONFIG</button>
          </div>
       </div>
    </div>
  );
}

// --- WIDGET COMPONENTS ---

const TimeSinkWidget: React.FC<{ startTime: number | null, isActive: boolean }> = ({ startTime, isActive }) => {
  const [elapsed, setElapsed] = useState(0);
  const [burnRate, setBurnRate] = useState(4.50);

  useEffect(() => {
    if (!startTime || !isActive) return;
    const interval = setInterval(() => {
      setElapsed(Date.now() - startTime);
    }, 100);
    return () => clearInterval(interval);
  }, [startTime, isActive]);

  const wasted = (elapsed / 60000) * burnRate;
  const seconds = Math.floor((elapsed / 1000) % 60);
  const minutes = Math.floor((elapsed / 1000 / 60));

  return (
    <div className="bg-void-800/80 border border-crimson/20 rounded-lg p-4 relative overflow-hidden group shadow-lg hover:border-crimson/40 transition-colors">
      <div className="absolute top-0 right-0 p-2">
        <div className={`w-2 h-2 rounded-full ${isActive ? 'bg-crimson animate-pulse shadow-[0_0_15px_#ff0033]' : 'bg-void-700'}`}></div>
      </div>
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
      <div className="flex justify-between items-center mb-4 relative z-10">
         <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
           <i className="fas fa-stopwatch text-crimson"></i> Time-Sink Active
         </div>
         <select 
           value={burnRate}
           onChange={(e) => setBurnRate(parseFloat(e.target.value))}
           className="bg-void-950 border border-crimson/20 text-[9px] text-slate-400 rounded px-2 py-0.5 outline-none focus:border-crimson focus:text-white"
         >
           <option value={0.50}>L1: Script Kiddie</option>
           <option value={4.50}>L2: Call Center</option>
           <option value={15.00}>L3: Syndicate</option>
         </select>
      </div>
      <div className="flex justify-between items-end relative z-10">
        <div>
           <div className="text-3xl font-mono font-bold text-crimson leading-none drop-shadow-[0_0_15px_rgba(255,0,51,0.5)] flex items-baseline">
             <span className="text-lg mr-1 opacity-70">$</span>
             {wasted.toFixed(4)}
           </div>
           <div className="text-[9px] font-bold text-crimson/70 uppercase mt-1">Est. Resource Burn</div>
        </div>
        <div className="text-right">
           <div className="text-sm font-mono text-slate-400 tabular-nums">
             {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
           </div>
           <div className="text-[8px] text-slate-600 uppercase tracking-wider">Engagement Duration</div>
        </div>
      </div>
    </div>
  );
};

const PredatorRadarChart: React.FC<{ metrics: PredatorMetrics | undefined }> = ({ metrics }) => {
  const urgency = metrics?.urgency_score || 0;
  const authority = metrics?.authority_score || 0;
  const exploitation = metrics?.exploitation_score || 0;

  const uX = 50 + 40 * (urgency / 100) * Math.cos(-Math.PI / 2);
  const uY = 50 + 40 * (urgency / 100) * Math.sin(-Math.PI / 2);
  const aX = 50 + 40 * (authority / 100) * Math.cos(Math.PI / 6);
  const aY = 50 + 40 * (authority / 100) * Math.sin(Math.PI / 6);
  const eX = 50 + 40 * (exploitation / 100) * Math.cos(5 * Math.PI / 6);
  const eY = 50 + 40 * (exploitation / 100) * Math.sin(5 * Math.PI / 6);

  const points = `${uX},${uY} ${aX},${aY} ${eX},${eY}`;

  return (
    <div className="w-full h-48 bg-void-800/80 rounded-lg border border-crimson/20 relative flex items-center justify-center overflow-hidden hover:border-crimson/40 transition-colors">
        <div className="absolute top-3 left-3 flex items-center gap-2">
            <i className="fas fa-crosshairs text-crimson text-[10px] animate-pulse"></i>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Predator Intent Radar</span>
        </div>
        <svg viewBox="0 0 100 100" className="w-32 h-32 opacity-20">
            <polygon points="50,10 85,80 15,80" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-slate-500" />
            <polygon points="50,30 67,65 33,65" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-slate-500" />
            <line x1="50" y1="50" x2="50" y2="10" stroke="currentColor" strokeWidth="0.5" className="text-slate-500" />
            <line x1="50" y1="50" x2="85" y2="80" stroke="currentColor" strokeWidth="0.5" className="text-slate-500" />
            <line x1="50" y1="50" x2="15" y2="80" stroke="currentColor" strokeWidth="0.5" className="text-slate-500" />
        </svg>
        <svg viewBox="0 0 100 100" className="w-32 h-32 absolute z-10 drop-shadow-[0_0_15px_rgba(255,0,51,0.5)]">
            <polygon points={points} fill="rgba(255, 0, 51, 0.2)" stroke="#ff0033" strokeWidth="1.5" className="transition-all duration-1000 ease-out" />
            <circle cx={uX} cy={uY} r="1.5" fill="#ff0033" />
            <circle cx={aX} cy={aY} r="1.5" fill="#ff0033" />
            <circle cx={eX} cy={eY} r="1.5" fill="#ff0033" />
        </svg>
        <div className="absolute top-6 left-1/2 -translate-x-1/2 text-[8px] font-bold text-amber-500 uppercase tracking-wider">Urgency</div>
        <div className="absolute bottom-6 right-8 text-[8px] font-bold text-crimson uppercase tracking-wider">Authority</div>
        <div className="absolute bottom-6 left-8 text-[8px] font-bold text-purple-500 uppercase tracking-wider">Exploitation</div>
    </div>
  );
};

// --- NEW COMPONENT: NETWORK GRAPH VISUALIZER ---
const NetworkGraphWidget: React.FC<{ graph?: NetworkGraphPayload }> = ({ graph }) => {
  const [nodes, setNodes] = useState<any[]>([]);
  const [edges, setEdges] = useState<any[]>([]);

  useEffect(() => {
    // Default Core Node
    const coreNode = { id: 'CORE', x: 50, y: 50, type: 'root', label: 'GLOBAL_INTEL_CORE' };
    
    if (!graph || !graph.nodes || graph.nodes.length === 0) {
        setNodes([coreNode]);
        setEdges([]);
        return;
    }

    // Basic Force-Directed-ish Layout (Deterministic Ring)
    const centerX = 50;
    const centerY = 50;
    
    // Process Nodes
    const mappedNodes = graph.nodes.map(n => ({ ...n, x: 50, y: 50 }));
    
    // 1. Fix Root
    const root = mappedNodes.find(n => n.type === 'root') || mappedNodes[0];
    if (root) { root.x = centerX; root.y = centerY; }

    // 2. Clusters (Orbit 1)
    const clusters = mappedNodes.filter(n => n.type === 'cluster');
    const clusterRadius = 25;
    clusters.forEach((node, i) => {
        const angle = (i / clusters.length) * 2 * Math.PI - (Math.PI / 2);
        node.x = centerX + clusterRadius * Math.cos(angle);
        node.y = centerY + clusterRadius * Math.sin(angle);
    });

    // 3. Entities (Orbit 2 or Local Cluster)
    const entities = mappedNodes.filter(n => !['root', 'cluster'].includes(n.type));
    const entityRadius = 40;
    entities.forEach((node, i) => {
        // Try to place near parent cluster if edge exists
        const connectedEdge = graph.edges.find(e => e.target === node.id || e.source === node.id);
        let angle = (i / entities.length) * 2 * Math.PI;
        
        if (connectedEdge) {
            const parentId = connectedEdge.source === node.id ? connectedEdge.target : connectedEdge.source;
            const parent = mappedNodes.find(n => n.id === parentId);
            if (parent && parent.type === 'cluster') {
                 // Calculate angle of parent
                 const dx = parent.x - centerX;
                 const dy = parent.y - centerY;
                 const parentAngle = Math.atan2(dy, dx);
                 // Offset slightly
                 angle = parentAngle + ((Math.random() - 0.5) * 0.5); 
            }
        }
        
        node.x = centerX + entityRadius * Math.cos(angle);
        node.y = centerY + entityRadius * Math.sin(angle);
    });

    setNodes(mappedNodes);
    setEdges(graph.edges);

  }, [graph]);

  return (
    <div className="w-full h-full bg-void-900 relative overflow-hidden group border border-crimson/10 rounded-lg">
       <div className="absolute top-2 left-2 z-10">
            <div className="text-[10px] font-black text-crimson uppercase tracking-widest flex items-center gap-2">
                <i className="fas fa-project-diagram animate-pulse"></i> Live Knowledge Graph
            </div>
            <div className="text-[8px] text-slate-500 font-mono mt-1">
                NODES: {nodes.length} | EDGES: {edges.length}
            </div>
       </div>
       
       <div className="absolute inset-0 grid-bg opacity-20"></div>

       <svg viewBox="0 0 100 100" className="w-full h-full relative z-0">
          <defs>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
               <feGaussianBlur stdDeviation="1" result="coloredBlur"/>
               <feMerge>
                   <feMergeNode in="coloredBlur"/>
                   <feMergeNode in="SourceGraphic"/>
               </feMerge>
            </filter>
            <marker id="arrow" markerWidth="4" markerHeight="4" refX="10" refY="2" orient="auto">
              <path d="M0,0 L0,4 L4,2 z" fill="#ff0033" opacity="0.6" />
            </marker>
          </defs>
          
          {edges.map((edge, i) => {
             const s = nodes.find(n => n.id === edge.source) || nodes[0];
             const t = nodes.find(n => n.id === edge.target) || nodes[0];
             return (
                 <g key={i}>
                    <line x1={s.x} y1={s.y} x2={t.x} y2={t.y} stroke="#ff0033" strokeWidth="0.2" opacity="0.3" markerEnd="url(#arrow)" />
                    <circle r="0.4" fill="#fff" filter="url(#glow)">
                        <animateMotion dur="2s" repeatCount="indefinite" path={`M${s.x},${s.y} L${t.x},${t.y}`} />
                    </circle>
                 </g>
             );
          })}

          {nodes.map((node, i) => (
              <g key={i} className="transition-all duration-700 ease-out" style={{ transformOrigin: `${node.x}px ${node.y}px` }}>
                  {node.type === 'root' && (
                       <circle cx={node.x} cy={node.y} r="10" fill="none" stroke="#ff0033" strokeWidth="0.1" opacity="0.3">
                           <animate attributeName="r" from="8" to="15" dur="3s" repeatCount="indefinite" />
                           <animate attributeName="opacity" from="0.3" to="0" dur="3s" repeatCount="indefinite" />
                       </circle>
                  )}
                  
                  <circle 
                    cx={node.x} cy={node.y} 
                    r={node.type === 'root' ? 4 : (node.type === 'cluster' ? 2.5 : 1.5)} 
                    fill={node.type === 'root' ? '#ff0033' : (node.type === 'cluster' ? '#000' : '#0a0a0a')}
                    stroke={node.type === 'root' ? '#fff' : '#ff0033'}
                    strokeWidth={node.type === 'root' ? 0 : 0.5}
                    filter="url(#glow)"
                    className="cursor-pointer"
                  />
                  
                  <text 
                    x={node.x} y={node.y + (node.type === 'root' ? 6 : 4)} 
                    fontSize={node.type === 'root' ? 3 : 2} 
                    fill={node.type === 'root' ? '#ff0033' : '#slate-400'} 
                    textAnchor="middle" 
                    fontFamily="monospace"
                    className="uppercase pointer-events-none"
                    style={{ fill: node.type === 'root' ? '#ff0033' : '#94a3b8' }}
                  >
                      {node.label.length > 15 ? node.label.substring(0, 12) + '...' : node.label}
                  </text>
              </g>
          ))}
       </svg>
    </div>
  );
};

// --- NEW COMPONENT: SHADOW KERNEL WIDGET (NEW VISUALIZER) ---
const ShadowKernelWidget: React.FC<{ telemetry?: ShadowTelemetry }> = ({ telemetry }) => {
  if (!telemetry) return (
     <div className="w-full bg-void-800/80 border border-crimson/20 rounded-lg p-4 h-32 flex items-center justify-center">
         <div className="text-[10px] text-slate-500 animate-pulse">SHADOW KERNEL: WAITING FOR UPLINK...</div>
     </div>
  );

  return (
     <div className="w-full bg-void-800/80 border border-crimson/20 rounded-lg p-4 flex flex-col hover:border-crimson/40 transition-colors relative overflow-hidden">
        {/* BG Scanner Effect */}
        <div className="absolute top-0 left-0 w-full h-1 bg-crimson/30 animate-scan-vertical pointer-events-none"></div>

        <div className="flex justify-between items-center mb-2 border-b border-crimson/10 pb-2">
            <div className="flex items-center gap-2">
               <i className="fas fa-ghost text-crimson animate-pulse"></i>
               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Shadow Sovereign Kernel</span>
            </div>
            <div className="text-[9px] font-mono text-crimson font-bold">{telemetry.threat_level}</div>
        </div>

        <div className="flex-1 grid grid-cols-2 gap-2 text-[9px] font-mono relative z-10">
            {/* Artifacts */}
            <div className="space-y-1">
               <div className="text-slate-500 uppercase text-[8px] tracking-wider mb-1">Live Artifacts</div>
               <div className="flex justify-between">
                  <span className="text-slate-400">IP TRACE:</span>
                  <span className="text-crimson truncate max-w-[80px]">{telemetry.live_artifacts.ip_address}</span>
               </div>
               <div className="flex justify-between">
                  <span className="text-slate-400">GPU HASH:</span>
                  <span className="text-slate-300 truncate max-w-[80px]">{telemetry.live_artifacts.gpu_hash}</span>
               </div>
               <div className="flex justify-between">
                  <span className="text-slate-400">DNA:</span>
                  <span className="text-slate-300 truncate max-w-[80px]">{telemetry.live_artifacts.linguistic_dna}</span>
               </div>
            </div>
            
            {/* Counter Measures */}
            <div className="space-y-1 border-l border-crimson/10 pl-2">
               <div className="text-slate-500 uppercase text-[8px] tracking-wider mb-1">Counter-Measures</div>
               <div className="flex justify-between">
                  <span className="text-slate-400">INJECTION:</span>
                  <span className="text-crimson font-bold">{telemetry.counter_measures.adversarial_injection}</span>
               </div>
               <div className="flex justify-between">
                  <span className="text-slate-400">SYNTHETIC:</span>
                  <span className="text-slate-300 truncate max-w-[80px]">{telemetry.counter_measures.synthetic_token_generated}</span>
               </div>
               <div className="flex justify-between mt-1">
                  <span className="text-slate-400">BURN ($):</span>
                  <span className="text-amber-500 font-bold text-[10px]">{telemetry.resource_burn_usd}</span>
               </div>
            </div>
        </div>
     </div>
  );
};

// --- NEW FUNCTIONAL COMPONENTS FOR PAGE 2 ---

const ThreatMap: React.FC<{ events: ScamEvent[] }> = ({ events }) => {
  return (
    <div className="relative w-full h-64 bg-void-900 border border-crimson/20 rounded-lg overflow-hidden flex items-center justify-center group">
      <div className="absolute inset-0 bg-[url('https://upload.wikimedia.org/wikipedia/commons/e/ec/World_map_blank_without_borders.svg')] bg-cover opacity-10 bg-center"></div>
      <div className="absolute inset-0 grid-bg opacity-20"></div>
      
      {/* REAL DATA MAPPING */}
      {events.length === 0 && (
          <div className="z-10 bg-void-950/80 border border-slate-700/30 px-4 py-2 rounded backdrop-blur text-[10px] text-slate-500 font-mono">
              WAITING FOR SIGNALS...
          </div>
      )}

      {events.slice(-5).map((ev, i) => (
          <div 
             key={i}
             className="absolute w-3 h-3 bg-crimson rounded-full animate-ping opacity-75"
             style={{ 
                 top: `${30 + (ev.score * 40)}%`, 
                 left: `${20 + (ev.messageIdx * 10) % 60}%`,
                 animationDelay: `${i * 0.5}s`
             }}
          ></div>
      ))}

      {events.length > 0 && (
          <div className="absolute bottom-2 right-2 flex flex-col items-end">
              <span className="text-[9px] font-mono text-crimson animate-pulse">THREATS DETECTED: {events.length}</span>
              <span className="text-[8px] text-slate-600">VECTOR TRIANGULATION ACTIVE</span>
          </div>
      )}
    </div>
  );
};

const CaseArchive: React.FC<{ 
    archives: ArchivedSession[], 
    onLoad: (s: ArchivedSession) => void 
}> = ({ archives, onLoad }) => {
  if (archives.length === 0) {
      return (
          <div className="text-center py-10 opacity-50 border border-dashed border-slate-800 rounded">
              <i className="fas fa-folder-open text-2xl mb-2 text-slate-600"></i>
              <div className="text-xs text-slate-500">NO DECRYPTED ARCHIVES FOUND</div>
          </div>
      );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {archives.map((session, i) => (
        <div key={session.id} onClick={() => onLoad(session)} className="bg-void-900 border border-crimson/10 p-4 rounded hover:border-crimson/50 hover:bg-void-800 transition-all cursor-pointer group">
          <div className="flex justify-between items-start mb-2">
             <div className="w-8 h-8 rounded bg-crimson/10 flex items-center justify-center text-crimson group-hover:bg-crimson group-hover:text-black transition-colors">
               <i className="fas fa-folder"></i>
             </div>
             <span className="text-[9px] font-mono text-slate-500">#{session.id.split('-')[2]}</span>
          </div>
          <div className="text-xs font-bold text-slate-300 mb-1">
              Score: {(session.threatScore * 100).toFixed(0)}%
          </div>
          <div className="text-[10px] text-slate-500 mb-3">
              Msgs: {session.messages.length} | <span className="text-crimson">{session.status}</span>
          </div>
          <div className="w-full h-1 bg-void-950 rounded overflow-hidden">
             <div className="h-full bg-crimson" style={{ width: `${session.threatScore * 100}%` }}></div>
          </div>
        </div>
      ))}
    </div>
  );
};

// --- MAIN APP COMPONENT ---

const App: React.FC = () => {
  // --- STATE ---
  // Core Session Data
  const [sessionId, setSessionId] = useState(`SEC-OPS-${Math.random().toString(36).substr(2, 6).toUpperCase()}`);
  const [messages, setMessages] = useState<Message[]>([]);
  const [analysis, setAnalysis] = useState<Partial<UnifiedAnalysis>>({});
  const [scamEvents, setScamEvents] = useState<ScamEvent[]>([]);
  const [agentState, setAgentState] = useState<AgentState>('INITIALIZING');
  
  // Archival Data
  const [archives, setArchives] = useState<ArchivedSession[]>(() => {
      const saved = localStorage.getItem('raashya_archives');
      return saved ? JSON.parse(saved) : [];
  });

  // UI & Input State
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'INTEL' | 'NETWORK' | 'LOGS'>('INTEL');
  const [showSystemArch, setShowSystemArch] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({ volume: 50, safeMode: true, autoStall: true });
  const [isListening, setIsListening] = useState(false);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);

  // KPIs
  const [globalKPIs, setGlobalKPIs] = useState<GlobalKPIs>({
    totalSessions: 1, totalIntelExtracted: 0, avgScamScore: 0, callbackSuccessRate: 100,
    callbackAttempts: 0, callbackSuccesses: 0, p95Latency: 0, detectionAccuracy: 0,
    safetyViolations: 0, scammerCostWasted: 0
  });

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    soundEngine.setVolume(settings.volume);
  }, [settings.volume]);

  // Sync Threat Level to Sound Engine
  useEffect(() => {
    soundEngine.setThreatLevel(analysis.scamScore || 0);
  }, [analysis.scamScore]);

  // Persist Archives
  useEffect(() => {
      localStorage.setItem('raashya_archives', JSON.stringify(archives));
  }, [archives]);

  // --- HANDLERS ---

  const handleJSONDownload = () => {
     const exportData = {
        metadata: { app: "Raashya Sovereign Vanguard", ver: "2.6.0" },
        session: { id: sessionId, data: messages, analysis },
        archives
     };
     const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
     const a = document.createElement('a');
     a.href = dataStr;
     a.download = `RAASHYA_FULL_DUMP_${sessionId}.json`;
     a.click();
     soundEngine.playSuccess();
  };

  const toggleListening = () => {
    soundEngine.init(); // Initialize audio context
    if (isListening) {
      if (recognitionRef.current) recognitionRef.current.stop();
      setIsListening(false);
    } else {
      const SpeechRecognition = window.webkitSpeechRecognition || (window as any).SpeechRecognition;
      if (!SpeechRecognition) { alert("Browser does not support Speech Recognition."); return; }
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognitionRef.current = recognition;
      recognition.onstart = () => { setIsListening(true); soundEngine.playActivation(); };
      recognition.onresult = (e: any) => {
        setInputText(prev => prev + (prev ? ' ' : '') + e.results[0][0].transcript);
        soundEngine.playTypewriter();
      };
      recognition.onend = () => setIsListening(false);
      recognition.start();
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    soundEngine.init(); // Initialize audio context
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => { setAttachedImage(reader.result as string); soundEngine.playBlip(); };
      reader.readAsDataURL(file);
    }
  };

  const handleProcess = useCallback(async (text: string) => {
    soundEngine.init(); // Initialize audio context on action
    if (!sessionStartTime) setSessionStartTime(Date.now());
    const start = performance.now();
    
    const newMsg: Message = { sender: 'scammer', text, timestamp: Date.now(), imageData: attachedImage || undefined };
    setAttachedImage(null);

    const updated = [...messages, newMsg];
    setMessages(updated);
    setIsProcessing(true);
    soundEngine.playBlip();

    try {
      const heuristics = analyzeMessageHeuristically(updated);
      const result = await processIncomingMessage(updated, agentState, heuristics, settings);
      
      setAnalysis(result);
      setAgentState(result.target_state as AgentState);
      setMessages(prev => [...prev, { sender: 'user', text: result.reply_text, timestamp: Date.now() }]);
      soundEngine.playTypewriter();
      
      if (result.scamScore > 0.7) soundEngine.playActivation();

      setScamEvents(prev => [...prev, {
          messageIdx: updated.length,
          score: result.scamScore,
          timestamp: Date.now(),
          signals: result.signal_breakdown.map(s => s.signal)
      }]);

      setGlobalKPIs(prev => ({
          ...prev,
          totalIntelExtracted: prev.totalIntelExtracted + (result.extracted_intel.upi_ids?.length || 0),
          p95Latency: performance.now() - start
      }));

      // --- CRITICAL AUDIT COMPLIANCE: SEND DATA TO HACKATHON BACKEND ---
      const callbackPayload: CallbackPayload = {
        sessionId,
        scamScore: result.scamScore,
        activatedAgent: result.activatedAgent,
        extractedIntelligence: result.extracted_intel,
        agentNotes: result.notes,
        action: result.action,
        totalMessages: updated.length,
        finalState: result.target_state as AgentState,
        latency: performance.now() - start,
        threatTags: result.threat_classification,
        safetyAudit: result.safety_audit,
        messageId: `MSG-${Date.now()}`
      };
      
      // Fire and forget (audit logging)
      sendCallbackWithRetry(callbackPayload, (log) => console.log("Callback Log:", log));

    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  }, [messages, agentState, sessionId, sessionStartTime, attachedImage, settings]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  // --- CORE FEATURE: SESSION ARCHIVING (NO DUMMY DATA) ---
  const archiveAndReset = () => {
      soundEngine.playSuccess();
      if (messages.length > 0) {
          const newArchive: ArchivedSession = {
              id: sessionId,
              timestamp: Date.now(),
              threatScore: analysis.scamScore || 0,
              messages: [...messages],
              intel: analysis.extracted_intel || { upi_ids: [], bank_accounts: [], links: [], phone_numbers: [], ifsc_codes: [], suspiciousKeywords: [] },
              metrics: analysis.predator_index || { urgency_score: 0, authority_score: 0, exploitation_score: 0, dominant_vector: 'EXPLOITATION' },
              personaUsed: analysis.persona || 'UNKNOWN',
              status: (analysis.scamScore || 0) > 0.8 ? 'NEUTRALIZED' : 'ACTIVE'
          };
          setArchives(prev => [newArchive, ...prev]);
      }
      
      // Reset State
      setSessionId(`SEC-OPS-${Math.random().toString(36).substr(2, 6).toUpperCase()}`);
      setMessages([]);
      setAnalysis({});
      setScamEvents([]);
      setSessionStartTime(null);
      setAttachedImage(null);
      setAgentState('INITIALIZING');
      soundEngine.playActivation();
  };

  const loadArchivedSession = (session: ArchivedSession) => {
      soundEngine.playBlip();
      if (confirm("Load archived session? Current progress will be lost if not archived.")) {
          setSessionId(session.id);
          setMessages(session.messages);
          setAnalysis({
              scamScore: session.threatScore,
              extracted_intel: session.intel,
              predator_index: session.metrics,
              persona: session.personaUsed as any,
              network_graph: { nodes: [], edges: [] } // Reset or load if archived (currently only session data stored)
          });
          // Reconstruct scam events roughly for visualization
          const reconstructedEvents = session.messages
              .filter(m => m.sender === 'scammer')
              .map((_, i) => ({
                  messageIdx: i,
                  score: session.threatScore, // Approx
                  timestamp: session.timestamp,
                  signals: ["ARCHIVED_SIGNAL"]
              }));
          setScamEvents(reconstructedEvents);
          window.scrollTo({ top: 0, behavior: 'smooth' });
      }
  };

  const handleJudicialExport = () => {
    if (!analysis || !sessionStartTime) { alert("Insufficient session data."); return; }
    soundEngine.playSuccess();
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        let y = 20;
        doc.setFont("helvetica", "bold"); doc.setTextColor(255, 0, 51); doc.setFontSize(22);
        doc.text("RAASHYA: SOVEREIGN VANGUARD", 105, y, { align: "center" });
        y += 10;
        doc.setFontSize(12); doc.setTextColor(0, 0, 0);
        doc.text("FORENSIC INTELLIGENCE REPORT (FIR-READY)", 105, y, { align: "center" });
        y += 20;
        doc.save(`RAASHYA_FIR_${sessionId}.pdf`);
    } catch (e) { alert("Error generating PDF."); }
  };

  const isCritical = (analysis.scamScore || 0) > 0.75;

  // --- RENDER ---
  return (
    <div className="w-full bg-void-950 text-slate-300 font-sans min-h-screen relative overflow-x-hidden">
      {/* GLOBAL RED ALERT OVERLAY */}
      <div className={`fixed inset-0 z-50 pointer-events-none transition-opacity duration-500 ${isCritical ? 'opacity-100 animate-flash-red shadow-[inset_0_0_100px_rgba(255,0,51,0.5)]' : 'opacity-0'}`}></div>
      
      <div className="absolute inset-0 grid-bg pointer-events-none z-0 fixed"></div>
      <div className="scanline-overlay"></div>

      {showSystemArch && <SystemArchModal onClose={() => setShowSystemArch(false)} />}
      {showSettings && <SettingsModal onClose={() => setShowSettings(false)} settings={settings} setSettings={setSettings} />}

      {/* HEADER */}
      <header className="fixed top-0 w-full z-50 bg-void-950/90 backdrop-blur border-b border-crimson/30 shadow-[0_5px_20px_rgba(0,0,0,0.5)]">
          <div className="h-16 flex items-center justify-center relative">
              <h1 className="text-3xl font-black tracking-[0.3em] text-transparent bg-clip-text bg-gradient-to-r from-crimson via-red-500 to-crimson uppercase font-mono animate-pulse-slow drop-shadow-[0_0_10px_rgba(255,0,51,0.5)]">
                  RAASHYA: <span className="text-white mx-4 opacity-20">|</span> SOVEREIGN VANGUARD
              </h1>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-4 text-[10px] text-slate-500 font-mono">
                  <span><i className="fas fa-satellite-dish animate-pulse text-crimson"></i> UPLINK_SECURE</span>
                  <div className="flex items-center gap-1 ml-4 border-l border-white/10 pl-4">
                      <span className="text-[8px] text-slate-400">GHOST_PROTOCOL:</span>
                      <span className={`text-[9px] font-bold ${analysis.activatedAgent ? 'text-crimson animate-pulse' : 'text-slate-600'}`}>
                         {analysis.activatedAgent ? 'ENGAGED' : 'STANDBY'}
                      </span>
                  </div>
              </div>
          </div>
      </header>

      {/* PAGE 1: OPERATIONAL DASHBOARD */}
      <div className="relative z-10 pt-16 flex flex-col h-screen">
        <div className="h-12 border-b border-crimson/20 bg-void-900 flex items-center justify-between px-6 shrink-0">
              <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2 text-[10px] font-bold tracking-widest text-slate-400">
                      <div className={`w-2 h-2 rounded-full ${isProcessing ? 'bg-amber-500' : 'bg-crimson'} animate-pulse shadow-[0_0_8px_#ff0033]`}></div>
                      STATUS: <span className="text-crimson">{isProcessing ? 'PROCESSING' : 'ACTIVE'}</span>
                  </div>
                  <div className="w-px h-4 bg-white/10"></div>
                  <div className="flex items-center gap-2 ml-4">
                      <div className="bg-void-800 border border-crimson/20 rounded px-2 py-1 flex items-center gap-2">
                          <i className="fas fa-database text-crimson text-[10px]"></i>
                          <div className="flex flex-col leading-none">
                              <span className="text-[7px] text-slate-500 uppercase">Intel</span>
                              <span className="text-[10px] font-bold text-white font-mono">{globalKPIs.totalIntelExtracted}</span>
                          </div>
                      </div>
                      <div className="bg-void-800 border border-crimson/20 rounded px-2 py-1 flex items-center gap-2">
                          <i className="fas fa-biohazard text-crimson text-[10px]"></i>
                          <div className="flex flex-col leading-none">
                              <span className="text-[7px] text-slate-500 uppercase">Threat</span>
                              <span className="text-[10px] font-bold text-white font-mono">{(analysis.scamScore || 0) * 100}%</span>
                          </div>
                      </div>
                  </div>
              </div>

              <div className="flex items-center gap-2">
                   <button onClick={() => setShowSettings(true)} className="bg-void-800 border border-crimson/20 text-slate-400 p-1.5 rounded hover:text-white hover:border-crimson transition-all"><i className="fas fa-cog"></i></button>
                   <button onClick={() => setShowSystemArch(true)} className="bg-void-800 border border-crimson/20 text-slate-300 px-3 py-1.5 rounded text-[9px] font-bold uppercase tracking-wider hover:bg-crimson hover:text-black transition-all"><i className="fas fa-network-wired mr-1"></i> System Arch</button>
                   <button onClick={handleJSONDownload} className="bg-void-800 border border-crimson/20 text-crimson px-3 py-1.5 rounded text-[9px] font-bold uppercase tracking-wider hover:bg-crimson hover:text-black transition-all"><i className="fas fa-download mr-1"></i> JSON</button>
                   <button onClick={handleJudicialExport} className="bg-crimson/10 border border-crimson/50 text-crimson px-3 py-1.5 rounded text-[9px] font-bold uppercase tracking-wider hover:bg-crimson hover:text-black transition-all shadow-[0_0_10px_rgba(255,0,51,0.2)]"><i className="fas fa-file-contract mr-1"></i> FIR PDF</button>
                   <button onClick={archiveAndReset} className="bg-void-800 border border-crimson/20 text-slate-500 px-3 py-1.5 rounded text-[9px] font-bold uppercase tracking-wider hover:text-crimson transition-colors">Archive & Reset</button>
              </div>
        </div>

        <div className="flex-1 grid grid-cols-12 gap-0 overflow-hidden">
            <main className="col-span-8 flex flex-col border-r border-crimson/20 bg-void-900/50 relative">
                <div className="h-10 border-b border-crimson/10 flex items-center justify-between px-4 bg-void-950/50">
                    <div className="text-[10px] font-mono text-slate-500 tracking-widest uppercase">
                        Live Feed <span className="text-slate-700 mx-1">//</span> {sessionId}
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">Active Persona:</span>
                        <span className="px-2 py-0.5 border border-crimson/30 bg-void-950 rounded text-[9px] font-bold text-crimson uppercase animate-pulse">
                            {analysis.persona || 'STANDBY'}
                        </span>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar relative">
                    {messages.length === 0 ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center opacity-20 pointer-events-none">
                            <div className="w-64 h-64 border border-crimson rounded-full flex items-center justify-center animate-pulse-slow">
                                 <i className="fas fa-shield-alt text-6xl text-crimson"></i>
                            </div>
                            <div className="mt-8 text-sm font-black tracking-[0.4em] uppercase text-crimson">Awaiting Hostile Vector</div>
                        </div>
                    ) : (
                        messages.map((m, i) => (
                            <div key={i} className={`flex ${m.sender === 'scammer' ? 'justify-start' : 'justify-end'} animate-in fade-in slide-in-from-bottom-2 duration-300`}>
                                <div className={`max-w-[80%] ${m.sender === 'scammer' ? 'text-left' : 'text-right'}`}>
                                    <div className="text-[9px] font-mono text-slate-500 mb-1 uppercase tracking-wider">
                                        {m.sender === 'scammer' ? 'Unknown Entity' : 'Raashya Agent'} <span className="opacity-50 mx-1">//</span> {new Date(m.timestamp).toLocaleTimeString()}
                                    </div>
                                    <div className={`p-4 rounded-sm border backdrop-blur-md relative overflow-hidden flex flex-col gap-2 ${
                                        m.sender === 'scammer' 
                                        ? 'bg-crimson/5 border-crimson/30 text-red-100 shadow-[0_0_15px_rgba(255,0,51,0.1)]' 
                                        : 'bg-void-800 border-void-700 text-slate-300'
                                    }`}>
                                        {m.imageData && (
                                            <div className="mb-2 rounded overflow-hidden border border-white/10 max-w-[200px]">
                                                <img src={m.imageData} alt="Attachment" className="w-full h-auto object-cover opacity-80" />
                                            </div>
                                        )}
                                        <p className="font-mono text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                    {isProcessing && <div className="flex gap-1 items-center p-2 text-xs font-mono text-crimson animate-pulse"><i className="fas fa-microchip animate-spin mr-2"></i> Analyzing Vector...</div>}
                    <div ref={chatEndRef}></div>
                </div>

                <div className="p-6 pt-2 pb-6">
                    <form onSubmit={(e) => { e.preventDefault(); if(inputText.trim() || attachedImage) { handleProcess(inputText); setInputText(''); } }} className="relative group">
                        {attachedImage && (
                            <div className="absolute -top-12 left-0 bg-void-800 border border-crimson rounded p-1 flex items-center gap-2 animate-in slide-in-from-bottom-2">
                                 <img src={attachedImage} alt="Preview" className="w-8 h-8 rounded object-cover" />
                                 <span className="text-[9px] text-crimson">Image attached</span>
                                 <button type="button" onClick={() => setAttachedImage(null)} className="text-crimson hover:text-white"><i className="fas fa-times"></i></button>
                            </div>
                        )}
                        <input 
                            value={inputText}
                            onChange={e => setInputText(e.target.value)}
                            disabled={isProcessing}
                            placeholder={isListening ? "LISTENING..." : "INPUT THREAT VECTOR MESSAGE..."}
                            className={`w-full h-14 bg-void-950/80 border rounded-lg pl-6 pr-32 font-mono text-sm text-white focus:bg-void-900 transition-all placeholder:text-slate-600 outline-none uppercase tracking-wide ${isListening ? 'border-crimson animate-pulse shadow-[0_0_15px_#ff0033]' : 'border-void-700 focus:border-crimson'}`}
                        />
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                            <button type="button" onClick={toggleListening} className={`w-8 h-8 flex items-center justify-center transition-all ${isListening ? 'text-crimson scale-110' : 'text-slate-500 hover:text-white'}`}>
                                <i className={`fas ${isListening ? 'fa-microphone-slash' : 'fa-microphone'}`}></i>
                            </button>
                            <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleImageUpload} />
                            <button type="button" onClick={() => fileInputRef.current?.click()} className="w-8 h-8 flex items-center justify-center text-slate-500 hover:text-white transition-colors"><i className="fas fa-paperclip"></i></button>
                            <button type="submit" disabled={!inputText.trim() && !attachedImage} className="w-10 h-10 rounded bg-crimson/10 border border-crimson/40 text-crimson hover:bg-crimson hover:text-black flex items-center justify-center transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-[0_0_10px_rgba(255,0,51,0.1)]"><i className="fas fa-arrow-right"></i></button>
                        </div>
                    </form>
                </div>
            </main>

            <aside className="col-span-4 bg-void-950 flex flex-col border-l border-crimson/20 p-4 space-y-4">
                <div className="flex items-center justify-between">
                    <div className="flex bg-void-800 rounded p-1 border border-crimson/10">
                        {['INTEL', 'NETWORK', 'LOGS'].map(tab => (
                            <button key={tab} onClick={() => setActiveTab(tab as any)} className={`px-3 py-1 rounded text-[9px] font-bold uppercase tracking-wider transition-all ${activeTab === tab ? 'bg-crimson text-black shadow' : 'text-slate-500 hover:text-slate-300'}`}>{tab}</button>
                        ))}
                    </div>
                    <div className="flex items-center bg-void-800 rounded px-2 py-1 border border-crimson/10 gap-2">
                        <span className="text-[8px] font-black uppercase text-slate-500">Threat Score</span>
                        <span className="text-[10px] font-mono font-bold text-white">{(analysis.scamScore || 0) * 100}%</span>
                    </div>
                </div>
                <TimeSinkWidget startTime={sessionStartTime} isActive={messages.length > 0} />
                <PredatorRadarChart metrics={analysis.predator_index} />
                <ShadowKernelWidget telemetry={analysis.shadow_telemetry} />
                <div className="flex-1 bg-void-800/30 border border-crimson/10 rounded-lg p-3 overflow-y-auto custom-scrollbar">
                    {activeTab === 'INTEL' && (
                        <div className="space-y-3">
                            <div className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Live Artifacts</div>
                            {analysis.extracted_intel?.links?.map((item, i) => (
                                 <div key={i} className="bg-void-900 border border-crimson/30 p-2 rounded flex items-center gap-2 hover:bg-void-800 transition-colors">
                                     <i className="fas fa-link text-crimson text-xs"></i>
                                     <div className="flex flex-col overflow-hidden"><span className="text-[9px] text-slate-400 truncate w-full">{item.value}</span><span className="text-[8px] text-crimson font-bold">MALICIOUS URL</span></div>
                                 </div>
                            ))}
                            {analysis.extracted_intel?.upi_ids?.map((item, i) => (
                                 <div key={i} className="bg-void-900 border border-amber-500/20 p-2 rounded flex items-center gap-2 hover:bg-void-800 transition-colors">
                                     <i className="fas fa-at text-amber-500 text-xs"></i>
                                     <div className="flex flex-col overflow-hidden"><span className="text-[9px] text-slate-400 truncate w-full">{item.value}</span><span className="text-[8px] text-amber-500 font-bold">PAYMENT NODE</span></div>
                                 </div>
                            ))}
                             {(!analysis.extracted_intel || (Object.values(analysis.extracted_intel).every((arr: any) => arr.length === 0))) && (
                                <div className="text-center py-4 opacity-30 text-[9px]">NO INTEL EXTRACTED</div>
                             )}
                        </div>
                    )}
                    {activeTab === 'NETWORK' && (
                        <NetworkGraphWidget graph={analysis.network_graph} />
                    )}
                    {activeTab === 'LOGS' && (
                        <div className="space-y-2 text-[9px] font-mono text-slate-400">
                            {scamEvents.slice().reverse().map((ev, i) => (
                               <div key={i} className="border-b border-white/5 pb-1 mb-1"><span className="text-slate-500">{new Date(ev.timestamp).toLocaleTimeString()}</span><span className="text-crimson mx-2">SCORE: {ev.score.toFixed(2)}</span><span className="text-white block">{ev.signals.join(', ')}</span></div>
                            ))}
                        </div>
                    )}
                </div>
            </aside>
        </div>
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce opacity-50"><span className="text-[8px] uppercase tracking-widest text-crimson">Scroll for Intel</span><i className="fas fa-chevron-down text-crimson mt-1"></i></div>
      </div>

      {/* PAGE 2: INTELLIGENCE ARCHIVES (CONNECTED) */}
      <div className="min-h-screen bg-void-950 border-t border-crimson/30 relative z-20 p-10 flex flex-col gap-10">
           <div className="flex items-center gap-4 mb-8">
               <div className="h-12 w-1 bg-crimson shadow-[0_0_15px_#ff0033]"></div>
               <div><h2 className="text-4xl font-black text-white tracking-widest uppercase">Global Threat Vector</h2><p className="text-sm text-crimson font-mono mt-1">LIVE INTELLIGENCE FEED // DECRYPTED ARCHIVES</p></div>
           </div>
           <div className="grid grid-cols-12 gap-8 flex-1">
               <div className="col-span-8 space-y-8">
                   <ThreatMap events={scamEvents} />
                   <div className="bg-void-900/50 border border-crimson/10 p-6 rounded-lg">
                       <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-4 border-b border-crimson/10 pb-2"><i className="fas fa-database mr-2 text-crimson"></i> Decrypted Case Files</h3>
                       <CaseArchive archives={archives} onLoad={loadArchivedSession} />
                   </div>
               </div>
               <div className="col-span-4 space-y-6">
                   <div className="bg-void-900 border border-crimson/20 p-6 rounded-lg">
                       <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">System Health</h3>
                       <div className="space-y-4">
                           <div className="flex items-center justify-between text-xs"><span className="text-slate-300">Consensus Engine</span><span className={`font-mono font-bold ${isProcessing ? 'text-amber-500' : 'text-crimson'}`}>{isProcessing ? 'COMPUTING' : 'ONLINE'}</span></div>
                           <div className="w-full h-1 bg-void-800 rounded overflow-hidden"><div className={`w-full h-full ${isProcessing ? 'bg-amber-500 animate-pulse' : 'bg-crimson'}`}></div></div>
                           <div className="flex items-center justify-between text-xs"><span className="text-slate-300">Ghosting Protocol</span><span className={`font-mono font-bold ${agentState === 'STALLING' ? 'text-crimson' : 'text-slate-500'}`}>{agentState === 'STALLING' ? 'ACTIVE' : 'STANDBY'}</span></div>
                           <div className="w-full h-1 bg-void-800 rounded overflow-hidden"><div className={`w-3/4 h-full ${agentState === 'STALLING' ? 'bg-crimson animate-pulse' : 'bg-slate-700'}`}></div></div>
                       </div>
                   </div>
                   <div className="bg-crimson/5 border border-crimson/20 p-6 rounded-lg">
                        <i className="fas fa-exclamation-triangle text-4xl text-crimson mb-4 opacity-50"></i>
                        <h3 className="text-lg font-bold text-white">Security Alert Level: {analysis.scamScore && analysis.scamScore > 0.7 ? 'CRITICAL' : 'MONITORING'}</h3>
                        <p className="text-xs text-slate-400 mt-2 leading-relaxed">System is actively monitoring input vectors. Archival nodes are synced. {archives.length} cases secured in local vault.</p>
                   </div>
               </div>
           </div>
      </div>
    </div>
  );
};

export default App;
