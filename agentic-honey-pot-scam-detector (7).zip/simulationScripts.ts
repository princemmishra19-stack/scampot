
import { SimulationScript } from './types';

export const SCAM_SCRIPTS: SimulationScript[] = [
  {
    id: 'bank_block',
    name: 'Bank Account Blockade',
    description: 'Simulates a social engineering attack claiming a frozen HDFC/SBI account.',
    messages: [
      'Dear Customer, your bank account is suspended due to KYC failure. Update immediately at https://bit.ly/bank-secure-update',
      'If you do not update in 1 hour, your balance of 45,000 will be frozen forever.',
      'Sir, please don’t worry. Just tell me your account number and I will help you from the backend.',
      'We need the OTP sent to your phone 9876543210 to verify your identity.'
    ]
  },
  {
    id: 'upi_refund',
    name: 'UPI Refund Trap',
    description: 'A "money back" scam targeting UPI users via QR codes or ID requests.',
    messages: [
      'Hello, you have a pending refund of ₹3,000 from your last Zomato order. Please confirm.',
      'To receive the money, send a request to paytm-refund-desk@oksbi',
      'It is showing error? Try sending to alternate ID: refund.support@axl',
      'Please scan this QR code and enter your PIN to authorize the receipt of funds.'
    ]
  },
  {
    id: 'job_offer',
    name: 'Remote Work Scam',
    description: 'High-paying part-time job offer requiring a "security deposit".',
    messages: [
      'Congratulations! You are selected for part-time Amazon Reviewer role. Earn 5000 daily.',
      'Join our Telegram for training: https://t.me/earn-daily-india-2024',
      'You need to pay a small registration fee of 500. Pay to UPI: hr.onboarding@icici',
      'Sir, 500 is refundable. Once you complete 1st task you get 1500 back.'
    ]
  }
];
