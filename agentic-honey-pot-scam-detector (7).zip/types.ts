
export type SenderType = 'scammer' | 'user' | 'system' | 'human_override';
export type AgentState = 'INITIALIZING' | 'PROBING' | 'EXTRACTING' | 'STALLING' | 'COMPLETED' | 'DISENGAGED' | 'HUMAN_TAKEOVER';

export interface Message {
  sender: SenderType;
  text: string;
  timestamp: number;
  imageData?: string; // Base64 string for screenshots/images
}

export interface ConfidenceBreakdown {
  pattern_score: number;
  context_score: number;
  reinforcement_score: number;
  decay_penalty: number;
}

export interface IntelItem {
  value: string;
  source_idx: number;
  confidence: number;
  provenance: string;
  evidence_snippets: string[];
  first_msg_idx: number;
  confirmation_count: number;
  confidence_breakdown: ConfidenceBreakdown;
  domain?: string;
  sandbox_recommendation?: string | null;
}

export interface SignalBreakdown {
  signal: string;
  weight: number;
  description: string;
}

export interface StateTransition {
  from: AgentState;
  to: AgentState;
  reason: string;
  timestamp: number;
}

export interface ScamEvent {
  messageIdx: number;
  score: number;
  timestamp: number;
  signals: string[];
}

export interface ThreatTag {
  category: 'FINANCIAL_FRAUD' | 'PHISHING' | 'JOB_SCAM' | 'ADVANCE_FEE' | 'IMPERSONATION' | 'SOCIAL_ENGINEERING' | 'SEXTORTION' | 'UTILITY_SCAM' | 'COURIER_SCAM';
  confidence: number;
  reason: string;
}

export interface ForensicSentiment {
  urgency: number;
  fear: number;
  greed: number;
  hostility: number;
  formal_deception: number;
}

export interface PredatorMetrics {
  urgency_score: number;      // Time-pressure (0-100)
  authority_score: number;    // Impersonation/Legal threats (0-100)
  exploitation_score: number; // Emotional manipulation/Greed (0-100)
  dominant_vector: 'URGENCY' | 'AUTHORITY' | 'EXPLOITATION';
}

export interface ForensicIntent {
  primary_goal: string;
  social_engineering_technique: string;
  target_asset: string;
}

export interface EthicsSafetyReport {
  isFictionalPersonaMaintained: boolean;
  noSensitiveDataLeaked: boolean;
  noImpersonationOfRealEntities: boolean;
  humanInterventionRequired: boolean;
  safetyFlags: string[];
}

// --- NEW TYPES FOR KNOWLEDGE GRAPH ---
export interface GraphNode {
  id: string;
  label: string;
  type: 'root' | 'entity' | 'cluster' | 'ip' | 'device' | 'location';
  x?: number; // For visualization
  y?: number;
}

export interface GraphEdge {
  source: string;
  target: string;
  label: string;
}

export interface NetworkGraphPayload {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

// --- NEW TYPES FOR DEEP-VOICE SCANNER ---
export interface DeepVoiceAnalysis {
  is_voice_present: boolean;
  ai_probability: number; // 0-100
  artifacts: string[]; // e.g. "metallic_tinnitus", "zero_breath", "spectral_cut"
  suspected_model: 'ElevenLabs' | 'VALL-E' | 'Tortoise' | 'Human' | 'Unknown';
}

// --- NEW TYPES FOR SHADOW SOVEREIGN TELEMETRY ---
export interface ShadowTelemetry {
  threat_level: string; // e.g., "CRITICAL (98%)"
  live_artifacts: {
    ip_address: string;
    gpu_hash: string;
    linguistic_dna: string;
  };
  counter_measures: {
    time_sink_active: boolean;
    adversarial_injection: string; // e.g., "Deployed"
    synthetic_token_generated: string; // e.g., "YES (Canary Credit Card)"
  };
  resource_burn_usd: string;
  system_status: string;
  kill_switch_ready: boolean;
}

// --- NEW TYPES FOR JUDICIAL EXPORT ---
export interface LegalSummary {
  case_id: string;
  generated_at: string;
  modus_operandi: string;
  statutory_violations: string[]; // e.g. "Section 66D IT Act"
  severity_assessment: string;
  prosecution_readiness_score: number; // 0-100
  recommended_action: string;
}
// -------------------------------------

export interface UnifiedAnalysis {
  reply_text: string;
  scamScore: number;
  activatedAgent: boolean;
  persona: 'confused_user' | 'cautious_professional' | 'elderly_non_tech' | 'concerned_relative';
  extracted_intel: ExtractedIntel;
  signal_breakdown: SignalBreakdown[];
  threat_classification: ThreatTag[];
  sentiment_analysis: ForensicSentiment;
  predator_index: PredatorMetrics;
  intent_analysis: ForensicIntent;
  safety_audit: EthicsSafetyReport;
  target_state: AgentState;
  action: 'continue' | 'finalize' | 'wait';
  confidence: number;
  notes: string;
  latency?: number;
  network_graph?: NetworkGraphPayload; 
  deep_voice_analysis?: DeepVoiceAnalysis;
  shadow_telemetry?: ShadowTelemetry; // Added field for Shadow Sovereign
}

export interface ExtractedIntel {
  upi_ids: IntelItem[];
  phone_numbers: IntelItem[];
  bank_accounts: IntelItem[];
  ifsc_codes: IntelItem[];
  links: IntelItem[];
  suspiciousKeywords: { value: string; source_idx: number; confidence: number }[];
}

export interface GlobalKPIs {
  totalSessions: number;
  totalIntelExtracted: number;
  avgScamScore: number;
  callbackSuccessRate: number;
  callbackAttempts: number;
  callbackSuccesses: number;
  p95Latency: number;
  detectionAccuracy: number;
  safetyViolations: number;
  scammerCostWasted: number; // Estimated dollar value of wasted scammer time
}

export interface AuditLog {
  id: string;
  timestamp: number;
  action: string;
  actor: 'SYSTEM' | 'AGENT' | 'HUMAN';
  details: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
}

export interface CallbackLog {
  id: string;
  timestamp: number;
  status: 'pending' | 'success' | 'failed' | 'retrying';
  httpStatus?: number;
  attempt: number;
  payload: any;
  response?: string;
}

export interface CallbackPayload {
  sessionId: string;
  scamScore: number;
  activatedAgent: boolean;
  extractedIntelligence: ExtractedIntel;
  agentNotes: string;
  action: 'continue' | 'finalize' | 'wait';
  totalMessages: number;
  finalState: AgentState;
  latency: number;
  threatTags: ThreatTag[];
  safetyAudit: EthicsSafetyReport;
  messageId: string;
}

export interface SimulationScript {
  id: string;
  name: string;
  description: string;
  messages: string[];
}
